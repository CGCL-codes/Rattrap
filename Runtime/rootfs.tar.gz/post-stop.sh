#!/bin/sh
rm -rf /var/lib/lxc/8d35ab53-d774-4a83-aca1-b6bc63b75a95/rootfs/dev/__properties__
umount /var/lib/lxc/8d35ab53-d774-4a83-aca1-b6bc63b75a95/rootfs/system